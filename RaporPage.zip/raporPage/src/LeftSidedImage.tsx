import { Box, Flex, Image, Text } from "@chakra-ui/react";
import industrialPhoto from "./assets/furnacePic.png";

const pathname = window.location.pathname;
const pathNumber = pathname.split('/').pop(); 

export const furnaceNumber = pathNumber;

const LeftSidedImage = () => {
  return (
    <Flex justifyContent="center" alignItems="center">
      <Box position="relative" boxSize="md">
        <Image
          src={industrialPhoto}
          alt="Furnace"
        />
        <Flex
          position="absolute"
          top="70%" 
          left="27%" 
          transform="translate(-50%, -50%)" 
          color="white" 
          fontSize="7xl"
          fontWeight="bold" 
        >
          <Text>{furnaceNumber}</Text>
        </Flex>
      </Box>
    </Flex>
  );
};

export default LeftSidedImage;
