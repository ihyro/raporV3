import "./App.css";
import {
  Flex,
  Stack,
  Box,

  useColorModeValue,
} from "@chakra-ui/react";
import imgSrc from "./assets/hemaisil.png";
import RaporPage from "./RaporPage";
import DarkModeBtn from "./DarkModeBtn";


// import { Route, Routes,  BrowserRouter } from "react-router-dom";
// import PageOne from './pages/pageOne';
// import PageTwo from './pages/pageTwo';
// import NotFound from './pages/NotFound';



function App() {
  return (
    
    <>
    {/* <BrowserRouter>
    <Stack>
        <Routes>
        <Route path='/pageOne' element={<PageOne />} />
        <Route path='/pageTwo' element={<PageTwo />} />
        <Route path='/*' element={<NotFound></NotFound>} />

        </Routes>
      </Stack>
      </BrowserRouter> */}

      <Box bg={useColorModeValue("gray.100", "gray.900")} px={4} >
        <Flex h={16} alignItems={"center"} justifyContent={"space-between"}>
          <Box boxSize={40} pt={14}>
            <img src={imgSrc} alt="hemaicon" />
          </Box>
          <Flex alignItems={"center"}>
            <Stack direction={"row"} spacing={7}>
            <Stack pl={17}>
              <DarkModeBtn />
            </Stack>
            </Stack>
          </Flex>
        </Flex>
      </Box>
      <div className="container">
          <RaporPage />
      </div>

    </>
  );
}

export default App;

