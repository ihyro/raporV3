import { useRef, useState, useEffect } from "react";


import {
  Box,
  Button,
  Text,
  Flex,
  Stack,
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  HStack,
} from "@chakra-ui/react";
import {
  FaRegFilePdf,
  FaChevronRight,
  FaHourglassStart,
  FaHourglassEnd,
  
} from "react-icons/fa";
import {
  MdDriveFileRenameOutline,
  MdOutlineAccountTree,
  MdOutlineEnergySavingsLeaf,
  MdGasMeter,
} from "react-icons/md";
import { GiFurnace } from "react-icons/gi";
import { BsClock, BsLightningCharge } from "react-icons/bs";
import { FaTemperatureArrowDown,FaTemperatureEmpty } from "react-icons/fa6";


import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import LeftSidedImage from "./LeftSidedImage";
import { BiCalendarPlus } from "react-icons/bi";


import { furnaceNumber } from './LeftSidedImage';


const RaporPage = () => {
  const printRef = useRef<HTMLDivElement | null>(null);
  const [todos, setTodos] = useState<any[]>([]);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const promises = [];
        for (let id = 1; id <= 10; id++) {
          promises.push(fetch(`https://jsonplaceholder.typicode.com/todos/${id}`).then(res => res.json()));
        }
        const results = await Promise.all(promises);
        setTodos(results);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);
  
  const handleDownloadPdf = async () => {
    const element = printRef.current;
    if (element) {
      const canvas = await html2canvas(element);
      const data = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      const imgProperties = pdf.getImageProperties(data);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProperties.height * pdfWidth) / imgProperties.width;
      pdf.addImage(data, "PNG", 10, 0, pdfWidth, pdfHeight);
      pdf.save("rapor.pdf");
    }
  };

  return (
    
    <Stack>
      <Box mt={1}>
        <Stack>
          <Flex>
            <Breadcrumb
              spacing="8px"
              separator={<FaChevronRight color="gray.500" />}
            >
              <BreadcrumbItem>
                <BreadcrumbLink href="#1" color="gray">Anasayfa</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbItem>
                <BreadcrumbLink href="#2" color="gray">Fırınlar</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbItem isCurrentPage>
                <BreadcrumbLink color="gray">Fırın 3 Rapor</BreadcrumbLink>
              </BreadcrumbItem>
            </Breadcrumb>
          </Flex>
          <Button
            leftIcon={<FaRegFilePdf />}
            w={40}
            mb={30}
            mt={-10}
            alignSelf="end"
            variant="outline"
            onClick={handleDownloadPdf}
          >
            PDF
          </Button>
        </Stack>
      </Box>

      <Flex justifyContent="space-between" alignItems="center">
        <Box boxSize={400}>
        <LeftSidedImage />
        </Box>
        <Box ref={printRef} w={500}>
          <Stack spacing={1.5} >
            <Flex justify="asd" as="b" fontSize="30px" >
            <Text color="gray">{`Fırın ${furnaceNumber} Rapor`}</Text>
            </Flex>

            <hr color="gray" />

            {/* Parça Adı */}
            <Flex>
              <HStack w={270}>
                <MdDriveFileRenameOutline data-html2canvas-ignore="true" />
                <Text color="gray">Parça Adı:</Text>
              </HStack>
              <Text color="gray">{todos[0]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />

            {/* Fırın Adı */}
            <Flex>
            <HStack w={270}>
            <GiFurnace data-html2canvas-ignore="true" />
            <Text color="gray">Fırın Adı:</Text>
            </HStack>
            <Text color="gray">{furnaceNumber}</Text>
          </Flex>

            <hr color="gray" />

            {/* Şarj Numarası */}
            <Flex>
              <HStack w={270}>
                <BsLightningCharge data-html2canvas-ignore="true" />
                <Text color="gray">Şarj Numarası:</Text>
              </HStack>
              <Text color="gray">{todos[2]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />

            {/* Parça Adeti */}
            <Flex>
              <HStack w={270}>
                <MdOutlineAccountTree data-html2canvas-ignore="true" />
                <Text color="gray">Parça Adeti:</Text>
              </HStack>
              <Text color="gray">{todos[3]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>
          

            <hr color="gray" />

            {/* Enerji */}
            <Flex>
              <HStack w={270}>
                <MdOutlineEnergySavingsLeaf data-html2canvas-ignore="true" />
                <Text color="gray">Enerji:</Text>
              </HStack>
              <Text color="gray">{"3459 kWh"}</Text>
            </Flex>

            <hr color="gray" />

            {/* Gaz */}
            <Flex>
              <HStack w={270}>
                <MdGasMeter data-html2canvas-ignore="true" />
                <Text color="gray">Gaz:</Text>
              </HStack>
              <Text color="gray">{"31 m³"}</Text>
            </Flex>

            <hr color="gray" />
                      {/* Oluşturulma Tarihi */}
              <Flex>
              <HStack w={270}>
                <BiCalendarPlus data-html2canvas-ignore="true" />
                <Text color="gray">Rapor Oluşturulma Zamanı:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>


            <hr color="gray" />
                      {/* Isıtma Bölgesi Giriş Zamanı */}
              <Flex>
              <HStack w={270}>
                <FaHourglassStart data-html2canvas-ignore="true" />
                <Text  color="gray">Isıtma Bölgesi Giriş Zamanı:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />
                      {/* Isıtma Bölgesi Çıkış Zamanı */}
              <Flex>
              <HStack w={270}>
                <FaHourglassEnd   data-html2canvas-ignore="true" />
                <Text color="gray">Isıtma Bölgesi Çıkış Zamanı:</Text>
              </HStack>
              <Text  color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />
                      {/* Isıtma Bölgesi Geçen Zaman */}
              <Flex>
              <HStack w={270}>
                <BsClock data-html2canvas-ignore="true" />
                <Text  color="gray">Isıtma Bölgesi Geçen Zaman:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />
                      {/* Soğuma Bölgesi Giriş Zamanı */}
              <Flex>
              <HStack w={270}>
                <FaTemperatureArrowDown data-html2canvas-ignore="true" />
                <Text color="gray">Soğuma Bölgesi Giriş Zamanı:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>

            <hr color="gray" />
                      {/* Soğuma Bölgesi Çıkış Zamanı */}
              <Flex>
              <HStack w={270} >
                <FaTemperatureEmpty data-html2canvas-ignore="true" />
                <Text  color="gray">Soğuma Bölgesi Çıkış Zamanı:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>


            <hr color="gray" />
                      {/* Soğuma Bölgesi Geçen Zaman */}
              <Flex>
              <HStack w={270}>
                <BsClock data-html2canvas-ignore="true" />
                <Text  color="gray">Soğuma Bölgesi Geçen Zaman:</Text>
              </HStack>
              <Text color="gray">{todos[9]?.completed?.toString() || 'Loading...'}</Text>
            </Flex>
            <hr color="gray" />


          </Stack>
        </Box>
      </Flex>
    </Stack>
  );
};

export default RaporPage;
