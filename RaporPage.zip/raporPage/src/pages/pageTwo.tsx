import React from 'react'

function pageTwo() {
  return (
    <div>pageTwo</div>
  )
}

export default pageTwo