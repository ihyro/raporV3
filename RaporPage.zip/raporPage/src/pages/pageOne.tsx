import React from 'react'

function pageOne() {
  return (
    <div>pageOne</div>
  )
}

export default pageOne