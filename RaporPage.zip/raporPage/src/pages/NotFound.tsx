import React from 'react'

function nf() {
  return (
    <div>sayfayok
    </div>
  )
}

export default nf